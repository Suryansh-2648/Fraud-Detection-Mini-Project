"""
YOUR SOLUTION. Rename nothing; implement the three methods.

  python run.py --engine submission_template --test test_r1.csv --out submission.csv

txn is a dict with keys:
  txn_id, user_id, timestamp ("YYYY-MM-DD HH:MM:SS"), amount, merchant_category, device_id,
  ip_address, lat, lon, account_age_days, failed_attempts, beneficiary_id, channel
(values may be missing / NaN)

score() must return:
  {"risk_score": float 0-100,          # used for PR-AUC ranking
   "prediction": 0 or 1,               # used for F2 and cost
   "reasons": ["CODE_1", "CODE_2"]}    # 1-3 reason codes, REQUIRED whenever prediction == 1
"""


class FraudEngine:
    def fit(self, train_df):
        # TODO: learn from train_df (labelled). Build per-user / per-device history here.
        pass

    def score(self, txn: dict) -> dict:
        # TODO: use ONLY information from train_df and earlier transactions (see update()).
        return {"risk_score": 0.0, "prediction": 0, "reasons": []}

    def update(self, txn: dict):
        # TODO: update your running state (device->users, user->recent txns, graph edges, ...)
        pass
