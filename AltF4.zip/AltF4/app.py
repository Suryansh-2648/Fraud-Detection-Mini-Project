"""Team AltF4 - Project Phantom dashboard.  Run:  streamlit run app.py
Keep next to: team_altf4.py, metrics.py, train.csv (and test_r1.csv for the demo button)."""
import copy
import time
import numpy as np
import pandas as pd
import streamlit as st
import team_altf4 as tp
from metrics import composite

REQUIRED = ["txn_id", "user_id", "timestamp", "amount", "merchant_category", "device_id",
            "ip_address", "lat", "lon", "account_age_days", "failed_attempts",
            "beneficiary_id", "channel"]

st.set_page_config(page_title="Team AltF4 - Project Phantom", layout="wide")
st.title("Team AltF4: Project Phantom - Real-Time Fraud Detection")


@st.cache_data
def load_train():
    return pd.read_csv("train.csv")


@st.cache_resource
def fitted_engine():
    eng = tp.FraudEngine()
    eng.fit(load_train().copy())
    return eng


def stream(engine, df):
    """Feed rows one at a time in time order, exactly like run.py."""
    recs = df.drop(columns=["label"], errors="ignore").to_dict("records")
    rows, lat = [], []
    bar = st.progress(0.0)
    for i, t in enumerate(recs):
        s = time.perf_counter()
        r = engine.score(dict(t))
        lat.append((time.perf_counter() - s) * 1000)
        engine.update(dict(t))
        rows.append((t["txn_id"], r["risk_score"], r["prediction"], "|".join(r["reasons"])))
        if i % 2000 == 0:
            bar.progress(i / len(recs))
    bar.empty()
    out = pd.DataFrame(rows, columns=["txn_id", "risk_score", "prediction", "reasons"])
    return out, np.array(lat)


def predict_file(df):
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        st.error(f"Missing columns: {missing}")
        return
    if df.txn_id.duplicated().any():
        st.warning(f"{int(df.txn_id.duplicated().sum())} duplicate txn_id rows found (kept as is).")
    df = df.sort_values(["timestamp", "txn_id"], kind="stable").reset_index(drop=True)
    with st.spinner("Preparing engine (first time trains on train.csv)..."):
        engine = copy.deepcopy(fitted_engine())   # fresh memory for every file
    out, lat = stream(engine, df)
    st.session_state["res"] = (out, df, lat)


tab1, tab2 = st.tabs(["Predict on a file", "Accuracy check (practice exam)"])

with tab1:
    up = st.file_uploader("Drag and drop a transactions CSV (same columns as test_r1.csv)", type="csv")
    c1, c2 = st.columns(2)
    if c1.button("Predict uploaded file", disabled=up is None):
        predict_file(pd.read_csv(up))
    if c2.button("Or run the demo file test_r1.csv"):
        predict_file(pd.read_csv("test_r1.csv"))

    if "res" in st.session_state:
        out, df, lat = st.session_state["res"]
        o = out.merge(df, on="txn_id")
        c = st.columns(4)
        c[0].metric("Transactions", f"{len(o):,}")
        c[1].metric("Flagged", f"{int(o.prediction.sum()):,}", f"{o.prediction.mean():.2%}")
        c[2].metric("p95 latency", f"{np.percentile(lat, 95):.2f} ms", "limit 50 ms")
        fl = o[o.prediction == 1]
        c[3].metric("Flagged with reasons", f"{(fl.reasons != '').mean():.0%}" if len(fl) else "n/a")

        if "label" in df.columns:
            m = composite(o.label.values, o.risk_score.values, o.prediction.values, o.amount.values)
            st.subheader("Accuracy (file contains labels)")
            st.dataframe(pd.DataFrame([{"PR-AUC": m["pr_auc"], "F2": m["f2"],
                                        "Cost-saving": m["cost"], "Composite": m["composite"]}]).round(3))
        else:
            st.info("No label column in this file, so no accuracy score can be computed. "
                    "Showing predictions only.")

        left, right = st.columns(2)
        left.subheader("Risk scores of rows scoring 5 or more")
        hi = o.risk_score[o.risk_score >= 5]
        if len(hi):
            left.bar_chart(pd.Series(np.histogram(hi, bins=19, range=(5, 100))[0]))
        right.subheader("Reason codes on flagged rows")
        if len(fl):
            right.bar_chart(fl.reasons.str.split("|").explode().value_counts())

        st.subheader("Flagged transactions")
        thr = st.slider("Minimum risk score", 0, 100, 0)
        f = fl[fl.risk_score >= thr].sort_values("risk_score", ascending=False)
        st.dataframe(f[["txn_id", "risk_score", "reasons", "user_id", "amount",
                        "merchant_category", "beneficiary_id", "timestamp"]], width="stretch")
        st.download_button("Download submission.csv",
                           out.to_csv(index=False), "submission.csv", "text/csv")

with tab2:
    st.write("Train on earlier months, test on the next one (labels known).")
    if st.button("Run rolling validation"):
        d = load_train().drop_duplicates("txn_id").sort_values(["timestamp", "txn_id"], kind="stable")
        folds = [("Jan->Feb", "2026-01-01", "2026-02-01", "2026-03-01"),
                 ("Jan-Feb->Mar", "2026-01-01", "2026-03-01", "2026-04-01"),
                 ("Jan-Mar->Apr", "2026-01-01", "2026-04-01", "2026-05-01")]
        res = []
        for name, a, b, c in folds:
            fit = d[(d.timestamp >= a) & (d.timestamp < b)]
            val = d[(d.timestamp >= b) & (d.timestamp < c)]
            with st.spinner(name):
                e = tp.FraudEngine()
                e.fit(fit.copy())
                out, _ = stream(e, val)
            m = composite(val.label.values, out.risk_score.values, out.prediction.values, val.amount.values)
            res.append({"fold": name, "PR-AUC": m["pr_auc"], "F2": m["f2"], "Cost-saving": m["cost"],
                        "Composite": m["composite"], "Flagged": int(out.prediction.sum()),
                        "Actual fraud": int(val.label.sum())})
        r = pd.DataFrame(res).set_index("fold")
        st.dataframe(r.style.format({k: "{:.3f}" for k in ["PR-AUC", "F2", "Cost-saving", "Composite"]}))
        st.bar_chart(r[["PR-AUC", "F2", "Cost-saving", "Composite"]], stack=False)