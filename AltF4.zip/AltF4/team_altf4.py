"""
PROJECT PHANTOM - streaming fraud engine (numpy + pandas + stdlib only).

  python run.py --engine team_phantom --test test_r1.csv --out submission.csv

Design
------
* State (dicts / sets / deques) is updated ONLY in update(); score() is read-only.
* fit() dedupes + sorts train, then REPLAYS it in time order through the same
  feature code used at test time, so every training feature is computed from
  strictly earlier rows (no look-ahead). The replayed state carries into test.
* Model: L2 logistic regression fitted with Newton/IRLS in numpy (deterministic).
* Flag rule: p >= P_MIN and p * amount_eff >= K * 150 (INR false-alarm cost).
  P_MIN and K are chosen inside fit() on out-of-time folds, for F2 + cost-saving.
* Reasons: top contributing features, mapped to readable codes.
"""
import math
from collections import deque
from datetime import date

import numpy as np

SEED = 7
FALSE_ALARM_COST = 150.0
SENTINEL = 1e6            # amounts >= this are placeholders (9,999,999), not real spend
AMT_CAP = 500000.0
CATS = ["crypto_exchange", "electronics", "food", "fuel", "gaming", "jewellery",
        "p2p_transfer", "travel", "utilities"]       # grocery = base level
CHANNELS = ["atm", "pos", "web"]                      # app = base level

# feature name -> reason code (several features may share a code)
CODE = {
    "log_amt": "HIGH_AMOUNT", "amt_z": "AMOUNT_SPIKE", "night": "ODD_HOUR",
    "dev_shared1": "SHARED_DEVICE", "dev_shared2": "SHARED_DEVICE",
    "ip_shared1": "SHARED_IP", "ip_shared3": "SHARED_IP",
    "bn_fan2": "MULE_BENEFICIARY", "bn_fan3": "MULE_BENEFICIARY", "u_fan3": "MULE_BENEFICIARY",
    "vel10_1": "VELOCITY_BURST", "vel10_2": "VELOCITY_BURST", "log_vel1h": "VELOCITY_BURST",
    "new_dev": "NEW_DEVICE", "cold_user": "NEW_USER_NO_HISTORY", "new_ben": "NEW_BENEFICIARY",
    "age_le7": "NEW_ACCOUNT", "age_8_30": "NEW_ACCOUNT",
    "fail1": "FAILED_ATTEMPTS", "fail2": "FAILED_ATTEMPTS", "fail3": "FAILED_ATTEMPTS",
    "bn": "EXTERNAL_BENEFICIARY", "u_ben": "P2P_BENEFICIARY",
    "speed_hi": "IMPOSSIBLE_TRAVEL", "log_speed": "IMPOSSIBLE_TRAVEL",
    "sentinel": "AMOUNT_OUTLIER", "ip_missing": "MISSING_IP", "geo_missing": "MISSING_GEO",
    "cat_missing": "UNKNOWN_CATEGORY",
    "new_age_x_big": "NEW_ACCOUNT", "bn_x_new_ben": "EXTERNAL_BENEFICIARY",
}
for _c in CATS:
    CODE["cat_" + _c] = "RISKY_CATEGORY"
for _c in CHANNELS:
    CODE["ch_" + _c] = "RISKY_CHANNEL"

NAMES = (["log_amt", "amt_z", "night", "dev_shared1", "dev_shared2", "ip_shared1", "ip_shared3",
          "bn_fan2", "bn_fan3", "u_fan3", "vel10_1", "vel10_2", "log_vel1h", "new_dev", "cold_user",
          "new_ben", "age_le7", "age_8_30", "fail1", "fail2", "fail3", "bn", "u_ben", "speed_hi",
          "log_speed", "sentinel", "ip_missing", "geo_missing", "cat_missing", "new_age_x_big",
          "bn_x_new_ben"]
         + ["cat_" + c for c in CATS] + ["ch_" + c for c in CHANNELS])
NF = len(NAMES)


def _nan(v):
    return v is None or v != v


def _ts(s):
    d = date(int(s[0:4]), int(s[5:7]), int(s[8:10]))
    return d.toordinal() * 86400 + int(s[11:13]) * 3600 + int(s[14:16]) * 60 + int(s[17:19])


def _sig(z):
    return 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))


# ---------------------------------------------------------------- metrics (for internal tuning)
def _f2(y, p):
    tp = float(((y == 1) & (p == 1)).sum()); fp = float(((y == 0) & (p == 1)).sum())
    fn = float(((y == 1) & (p == 0)).sum())
    pr = tp / max(tp + fp, 1.0); rc = tp / max(tp + fn, 1.0)
    return 0.0 if pr + rc == 0 else 5 * pr * rc / (4 * pr + rc)


def _cost(y, p, amt):
    tot = amt[y == 1].sum()
    if tot <= 0:
        return 0.0
    return 1.0 - (amt[(y == 1) & (p == 0)].sum() + FALSE_ALARM_COST * ((y == 0) & (p == 1)).sum()) / tot


class FraudEngine:
    LAM = 20.0
    # ------------------------------------------------------------------ state
    def _reset(self):
        self.u_dev = {}       # user -> trusted devices
        self.u_ben = {}       # user -> beneficiaries used
        self.u_amt = {}       # user -> [n, sum, sumsq] of log1p(amount)
        self.u_rec = {}       # user -> deque of timestamps (last hour)
        self.u_last = {}      # user -> (ts, lat, lon)
        self.dev_users = {}   # device -> users (capped)
        self.ip_users = {}
        self.ben_users = {}
        self.u_seen = set()

    @staticmethod
    def _eff_amount(amount):
        if _nan(amount):
            return 2000.0, 1
        if amount >= SENTINEL:
            return 2000.0, 1
        return min(float(amount), AMT_CAP), 0

    # --------------------------------------------------------------- features
    def _features(self, t):
        """Read-only: builds the feature vector from PAST state + this row's own fields."""
        u = t["user_id"]; dev = t["device_id"]; ip = t.get("ip_address"); ben = t["beneficiary_id"]
        ts_str = t["timestamp"]; ts = _ts(ts_str); hour = int(ts_str[11:13])
        amt, sent = self._eff_amount(t["amount"])
        la = math.log1p(amt)

        st = self.u_amt.get(u)
        if st and st[0] >= 3:
            mu = st[1] / st[0]; sd = max(st[2] / st[0] - mu * mu, 0.0) ** 0.5
            z = (la - mu) / max(sd, 0.3)
            z = max(-3.0, min(6.0, z))
        else:
            z = 0.0

        ds = self.dev_users.get(dev)
        dsh = (len(ds) - (1 if u in ds else 0)) if ds else 0
        if _nan(ip):
            ish = 0
        else:
            s = self.ip_users.get(ip); ish = (len(s) - (1 if u in s else 0)) if s else 0
        bs = self.ben_users.get(ben)
        bfan = (len(bs) - (1 if u in bs else 0)) if bs else 0
        is_bn = ben.startswith("BN"); is_u = ben.startswith("U")

        rec = self.u_rec.get(u)
        v10 = v1h = 0
        if rec:
            for r in rec:
                d = ts - r
                if d <= 3600:
                    v1h += 1
                    if d <= 600:
                        v10 += 1

        known = self.u_dev.get(u)
        new_dev = 1 if (known and dev not in known) else 0
        cold = 0 if u in self.u_seen else 1
        ubs = self.u_ben.get(u)
        new_ben = 1 if (ubs and ben not in ubs) else 0

        age = t["account_age_days"]; age = 10 ** 6 if _nan(age) else age
        fa = t["failed_attempts"]; fa = 0 if _nan(fa) else fa

        lat = t.get("lat"); lon = t.get("lon")
        geo_missing = 1 if (_nan(lat) or _nan(lon)) else 0
        speed = 0.0
        last = self.u_last.get(u)
        if last is not None and not geo_missing:
            dist = math.hypot(lat - last[1], lon - last[2]) * 111.0
            speed = dist / max((ts - last[0]) / 3600.0, 1.0 / 60.0)
        speed = min(speed, 5000.0)

        cat = t.get("merchant_category"); cat_missing = 1 if _nan(cat) else 0
        ch = t.get("channel")
        age_le7 = 1 if age <= 7 else 0
        age_8_30 = 1 if 7 < age <= 30 else 0

        x = [la, z, 1 if hour < 5 else 0, 1 if dsh >= 1 else 0, 1 if dsh >= 2 else 0,
             1 if ish >= 1 else 0, 1 if ish >= 3 else 0,
             1 if (is_bn and bfan >= 2) else 0, 1 if (is_bn and bfan >= 3) else 0,
             1 if (is_u and bfan >= 3) else 0,
             1 if v10 >= 1 else 0, 1 if v10 >= 2 else 0, math.log1p(v1h),
             new_dev, cold, new_ben, age_le7, age_8_30,
             1 if fa == 1 else 0, 1 if fa == 2 else 0, 1 if fa >= 3 else 0,
             1 if is_bn else 0, 1 if is_u else 0,
             1 if speed > 900 else 0, math.log1p(speed), sent,
             1 if _nan(ip) else 0, geo_missing, cat_missing,
             (age_le7 or age_8_30) * (1 if amt > 20000 else 0),
             (1 if is_bn else 0) * new_ben]
        x += [1 if cat == c else 0 for c in CATS]
        x += [1 if ch == c else 0 for c in CHANNELS]
        return x, amt

    # ----------------------------------------------------------------- update
    def _apply(self, t, trust_device=True):
        u = t["user_id"]; dev = t["device_id"]; ip = t.get("ip_address"); ben = t["beneficiary_id"]
        ts = _ts(t["timestamp"])
        amt, _ = self._eff_amount(t["amount"])
        la = math.log1p(amt)
        if trust_device:
            self.u_dev.setdefault(u, set()).add(dev)
        self.u_ben.setdefault(u, set()).add(ben)
        st = self.u_amt.get(u)
        if st is None:
            self.u_amt[u] = [1, la, la * la]
        else:
            st[0] += 1; st[1] += la; st[2] += la * la
        dq = self.u_rec.get(u)
        if dq is None:
            dq = self.u_rec[u] = deque()
        while dq and ts - dq[0] > 3600:
            dq.popleft()
        dq.append(ts)
        lat = t.get("lat"); lon = t.get("lon")
        if not (_nan(lat) or _nan(lon)):
            self.u_last[u] = (ts, lat, lon)
        for table, key, cap in ((self.dev_users, dev, 20), (self.ben_users, ben, 12)):
            s = table.get(key)
            if s is None:
                table[key] = {u}
            elif len(s) < cap:
                s.add(u)
        if not _nan(ip):
            s = self.ip_users.get(ip)
            if s is None:
                self.ip_users[ip] = {u}
            elif len(s) < 20:
                s.add(u)
        self.u_seen.add(u)

    # -------------------------------------------------------------------- fit
    def _newton(self, X, y, lam, iters=25):
        n, d = X.shape
        mu = X.mean(0); sd = X.std(0); sd[sd < 1e-9] = 1.0
        Z = (X - mu) / sd
        Z1 = np.hstack([Z, np.ones((n, 1))])
        w = np.zeros(d + 1)
        reg = np.full(d + 1, lam); reg[-1] = 0.0
        for _ in range(iters):
            p = _sig(Z1 @ w)
            g = Z1.T @ (p - y) + reg * w
            s = p * (1 - p) + 1e-9
            H = (Z1 * s[:, None]).T @ Z1 + np.diag(reg) + 1e-6 * np.eye(d + 1)
            step = np.linalg.solve(H, g)
            w -= step
            if np.abs(step).max() < 1e-6:
                break
        wr = w[:-1] / sd
        b = w[-1] - float((w[:-1] * mu / sd).sum())
        return wr, b

    def fit(self, train_df):
        np.random.seed(SEED)
        df = train_df.drop_duplicates("txn_id").copy()
        df = df.sort_values(["timestamp", "txn_id"], kind="stable")
        rows = df.to_dict("records")
        y = df["label"].to_numpy(dtype=float)

        # replay in time order: features come from strictly earlier rows
        self._reset()
        X = np.empty((len(rows), NF)); AMT = np.empty(len(rows)); TS = np.empty(len(rows))
        for i, t in enumerate(rows):
            x, a = self._features(t)
            X[i] = x; AMT[i] = a; TS[i] = _ts(t["timestamp"])
            # a known-fraud row must not make its device "trusted" for that user
            self._apply(t, trust_device=(y[i] == 0))
        raw_amt = np.array([0.0 if _nan(r["amount"]) or r["amount"] >= SENTINEL else r["amount"]
                            for r in rows])

        self.lam = self.LAM
        # internal out-of-time folds to pick the flag rule
        t0, t1 = TS.min(), TS.max()
        w = min(30 * 86400.0, (t1 - t0) * 0.25)
        folds = [(t1 - 2 * w, t1 - w), (t1 - w, t1 + 1)]
        ps, ys, ams = [], [], []
        for a, b in folds:
            tr = TS < a; ev = (TS >= a) & (TS < b)
            if tr.sum() < 1000 or y[tr].sum() < 20 or ev.sum() == 0:
                continue
            wr, bb = self._newton(X[tr], y[tr], self.lam)
            ps.append(_sig(X[ev] @ wr + bb)); ys.append(y[ev]); ams.append(raw_amt[ev]); 
        best = (-1.0, 0.2, 0.0)
        if ps:
            P = np.concatenate(ps); Y = np.concatenate(ys); A = np.concatenate(ams)
            Aeff = np.where(A > 0, np.minimum(A, AMT_CAP), 2000.0)
            for pmin in (0.02, 0.03, 0.05, 0.08, 0.12, 0.18, 0.25, 0.35, 0.5):
                for k in (0.0, 0.25, 0.5, 1.0, 2.0, 3.0, 5.0):
                    pred = ((P >= pmin) & (P * Aeff >= k * FALSE_ALARM_COST)).astype(int)
                    if pred.sum() == 0:
                        continue
                    obj = 0.5 * _f2(Y, pred) + 0.5 * _cost(Y, pred, A)
                    if obj > best[0]:
                        best = (obj, pmin, k)
        self.cv_obj, self.p_min, self.k = best

        # final model on all history
        self.w, self.b = self._newton(X, y, self.lam)
        self.x_mean = X.mean(0)
        self._last = None
        return self

    # ------------------------------------------------------------------ score
    def score(self, txn: dict) -> dict:
        x, amt = self._features(txn)
        xa = np.asarray(x)
        z = float(xa @ self.w + self.b)
        p = float(_sig(z))
        flag = (p >= self.p_min) and (p * amt >= self.k * FALSE_ALARM_COST)
        reasons = []
        if flag:
            contrib = self.w * (xa - self.x_mean)
            order = np.argsort(-contrib)
            for j in order:
                if contrib[j] <= 0.05 and reasons:
                    break
                code = CODE[NAMES[j]]
                if code not in reasons:
                    reasons.append(code)
                if len(reasons) == 3:
                    break
            if not reasons:
                reasons = ["HIGH_RISK_PATTERN"]
        self._last = (txn.get("txn_id"), flag)
        return {"risk_score": round(100.0 * p, 4), "prediction": int(flag), "reasons": reasons}

    def update(self, txn: dict):
        trust = True
        if self._last is not None and self._last[0] == txn.get("txn_id"):
            trust = not self._last[1]       # a flagged txn does not make its device trusted
        self._apply(txn, trust_device=trust)
