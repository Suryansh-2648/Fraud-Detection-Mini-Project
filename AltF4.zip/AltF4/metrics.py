import numpy as np, pandas as pd
def pr_auc(y, s):
    o=np.argsort(-s, kind="stable"); y=np.asarray(y)[o]; s=np.asarray(s)[o]
    tp=np.cumsum(y); fp=np.cumsum(1-y)
    # collapse ties
    last=np.r_[s[1:]!=s[:-1], True]
    tp,fp=tp[last],fp[last]
    prec=tp/(tp+fp); rec=tp/y.sum()
    rec0=np.r_[0,rec]; return float(np.sum((rec0[1:]-rec0[:-1])*prec))  # step AP
def fbeta(y,p,b=2):
    y=np.asarray(y);p=np.asarray(p); tp=((y==1)&(p==1)).sum(); fp=((y==0)&(p==1)).sum(); fn=((y==1)&(p==0)).sum()
    pr=tp/max(tp+fp,1); rc=tp/max(tp+fn,1)
    return 0 if pr+rc==0 else (1+b*b)*pr*rc/(b*b*pr+rc)
def cost_saving(y,p,amt):
    y=np.asarray(y);p=np.asarray(p);amt=np.asarray(amt)
    missed=amt[(y==1)&(p==0)].sum(); fp=((y==0)&(p==1)).sum(); tot=amt[y==1].sum()
    return 1-(missed+150*fp)/tot
def composite(y,s,p,amt):
    a,f,c=pr_auc(y,s),fbeta(y,p),cost_saving(y,p,amt)
    return dict(pr_auc=a,f2=f,cost=c,composite=0.4*a+0.3*f+0.3*c)
