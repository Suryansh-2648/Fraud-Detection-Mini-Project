# Project Phantom: Presentation and Reference Guide

Written for someone who is **not** from a machine-learning background. Every term is explained when it first appears. Use it as the base for the final documentation and as your speaking notes.

Files this guide refers to: `team_phantom.py` (the engine), `run.py` (the official runner), `validate_rolling.py` and `metrics.py` (accuracy checker), `app.py` (optional dashboard), `PHANTOM_AUDIT.md` (bug report on the baseline).

**A note on honesty.** Every number below was measured by running the code on the provided data. The accuracy numbers use *our own* version of the scoring formulas, because the organizers' scorer was not provided. Say that out loud in the defence. It builds trust.

---

## 1. The problem in one minute

A bank processes millions of payments. A tiny fraction (about 1 in 80, or 1.2%) are fraud. We must build a program that looks at each payment **the moment it arrives**, gives it a **risk score from 0 to 100**, decides **flag or don't flag**, and gives **reasons** for every flag.

Three hard rules shape everything:
1. **No peeking at the future.** When scoring a payment, we may only use the past. This is how a real bank works.
2. **Fast.** Each decision must take under 50 milliseconds. Ours takes about 0.09 ms.
3. **Explainable.** Every flagged payment needs 1 to 3 reason codes a human can read, such as `SHARED_DEVICE`.

**Why it's hard:**
- Fraud is rare, so a program that flags nothing is 98.8% "accurate" and completely useless.
- The data is messy: missing values, duplicate rows, a few wrong labels, and a fake "9,999,999" amount.
- Fraudsters change tactics over time ("concept drift"). May's fraud is not the same as January's.

## 2. How the competition is scored

`Final score = 0.4 × PR-AUC + 0.3 × F2 + 0.3 × Cost-saving`

Everything from 0 to 1. Higher is better.

| Metric | Plain-language meaning | Everyday analogy |
|---|---|---|
| **PR-AUC** | If we sort all payments from riskiest to safest, do the real frauds end up near the top? | A security guard who ranks passengers by suspicion. A good guard has the real smugglers in his top 10. |
| **F2** | Of the payments we flagged, how many were real fraud, and of all real fraud, how many did we catch, counting "catch them" as 4× more important than "avoid false alarms"? | A smoke alarm. A false alarm is annoying, but a missed fire is a disaster. |
| **Cost-saving** | In rupees: how much fraud money did we stop, after paying ₹150 for every false alarm? | A shop owner's profit and loss. |

**Why not plain accuracy?** Because 98.8% of payments are honest. Flagging nothing already "scores" 98.8%.

## 3. The big idea behind our solution

Fraud is rarely visible in a single payment. It shows up in **patterns across people, devices and time**. So our engine **remembers** what it has seen and compares each new payment against that memory.

> "We don't just look at the payment. We look at the payment's history: the user, the device, the network address, and where the money is going."

The questions our memory lets us answer:

| Question the engine asks | Why it points to fraud (plain English) | Reason code |
|---|---|---|
| Was this device already used by a *different* customer? | Fraud rings reuse the same phones and laptops across stolen accounts. | `SHARED_DEVICE` |
| Was this network (IP) address already used by a different customer? | Same idea: one fraudster, many accounts. | `SHARED_IP` |
| Did this same user pay several times in the last 10 minutes? | Fraudsters drain an account fast, in a burst. | `VELOCITY_BURST` |
| Is the account 30 days old or less? | Fraudsters use freshly created or freshly hijacked accounts. | `NEW_ACCOUNT` |
| Were there repeated failed attempts just before? | Someone guessing passwords. | `FAILED_ATTEMPTS` |
| Has the receiving external account already received money from several other customers? | A "mule account" that collects stolen money. | `MULE_BENEFICIARY` |
| Is this a risky type of purchase (crypto, jewellery, gaming, electronics)? | Easy to resell, so fraudsters love them. | `RISKY_CATEGORY` |
| Is it the middle of the night (0 to 5 am)? | Fraud rate jumps at those hours. | `ODD_HOUR` |
| Is the amount unusually large? | Bigger loot. | `HIGH_AMOUNT` |
| Is the amount very different from this user's normal? | Out of character. | `AMOUNT_SPIKE` |
| Did the user "teleport" (impossible travel speed)? | Two far-apart locations in minutes means two different people. | `IMPOSSIBLE_TRAVEL` |
| First time we see this device for this user? | Weak signal alone, but adds up. | `NEW_DEVICE` |

Strength of each signal in the training data (measured, shown as how often the signal was actually fraud):
- Device used by another customer: about **98%** fraud.
- Account 7 days old or less: **85%** fraud. Account 8 to 30 days old: **54%**. Older than 30 days: **under 1%**.
- 3 or more failed attempts: **85% to 100%** fraud.
- Another payment by the same user in the last 10 minutes: **36%**. Two or more: **about 99%**.
- Compared with about **1.2%** for a random payment.

## 4. The three stages of the engine

```
STAGE 1: LEARN (fit)          STAGE 2: JUDGE (score)           STAGE 3: REMEMBER (update)
Read 120,000 past payments    A new payment arrives            Add this payment to memory
Replay them in time order     Ask memory the questions         (so the next payment can use it)
Learn what predicts fraud     Compute risk 0-100
Pick the "flag" cut-off       Decide flag / no flag
                              Write reasons
```

The official runner (`run.py`) does this: `fit` once, then for each test payment `score` and then `update`, always in that order. **Order matters.** Scoring first and remembering second means a payment can never see itself.

## 5. Function-by-function walkthrough

All of this lives in `team_phantom.py`. For each function: what it does in plain words, and why it exists.

### Constants at the top
- `SEED = 7`: a fixed number so results are identical every run (reproducibility rule).
- `FALSE_ALARM_COST = 150`: the ₹150 penalty from the rules.
- `SENTINEL = 1e6`: any amount of ₹1,000,000 or more is treated as a fake placeholder. The data contains exactly `9,999,999` in 62 training rows and 22 test rows. None of the 62 training ones were fraud.
- `AMT_CAP = 500000`: very large amounts are capped so a single huge number can't distort things.
- `CODE`, `NAMES`: the list of 43 features the engine computes, and the mapping from each feature to a human-readable reason code.

### Small helper functions
| Function | Plain meaning |
|---|---|
| `_nan(v)` | "Is this value missing?" Missing values arrive as a special "not a number" value, not as an empty one, so a normal "is empty" check does not work. This helper handles it safely everywhere. |
| `_ts(s)` | Converts a text timestamp like `2026-05-01 14:30:05` into a plain number of seconds, so we can subtract two times to get "how long ago". |
| `_sig(z)` | The "squash" function. Turns any number into a probability between 0 and 1. Big positive means likely fraud; big negative means very unlikely. |
| `_f2(y, p)` and `_cost(y, p, amt)` | Our own copies of the F2 and cost-saving formulas, used **inside** `fit()` to choose the best flag cut-off. |

### `_reset()`
Creates an empty memory. Memory is made of dictionaries (think: labelled filing cabinets):
- per customer: devices they've used, receivers they've paid, average spending, payment times in the last hour, last known location;
- per device, per IP address, per receiver: the set of customers who have touched it.

Customer sets for devices, IPs and receivers are **capped** (20 for devices and IPs, 12 for receivers) so memory can never grow without bound.

### `_eff_amount(amount)`
Cleans the amount. A missing or placeholder amount (9,999,999) is replaced by a neutral ₹2,000, and a flag `sentinel` is raised so the model learns that these rows are junk, not fraud. Other amounts are capped at ₹500,000.

### `_features(t)`: the heart of the engine (read-only)
Takes one transaction and **only reads memory** to produce 43 numbers describing it. It never writes. That is what guarantees "no look-ahead" and that scoring twice gives identical results (we tested both).

The 43 features fall into groups:
- **Amount:** log of the amount (makes ₹100 vs ₹100,000 comparable), how unusual it is for this customer (needs at least 3 past payments, otherwise neutral).
- **Time:** is it between 0 and 5 am.
- **Sharing:** how many *other* customers used this device / IP (flags for 1+, 2+, 3+).
- **Receiver:** for external accounts (`BN…`) how many other customers already paid them (2+, 3+); same for customer-to-customer (`U…`); also whether the receiver is external or a customer.
- **Speed of activity:** payments by the same user in the last 10 minutes and in the last hour.
- **Newness:** new device for this user, first time ever seen this user, new receiver for this user.
- **Account:** age 7 days or less, age 8 to 30 days, and combinations such as new account with a large amount.
- **Failures:** 1, 2, or 3+ failed attempts.
- **Location:** travel speed from the user's previous location (flag if above 900 km/h), missing location.
- **Data quality:** placeholder amount, missing IP, missing category.
- **Category and channel:** which of 10 merchant categories and 4 channels (app, web, ATM, POS) the payment used.

### `_apply(t, trust_device)`: update the memory
Writes one transaction into memory: customer's devices and receivers, running average of spending, times of recent payments, last location, and the device / IP / receiver customer-sets. It also drops payments older than one hour from the "recent" list.

The `trust_device` switch is one of our fixes (explained in section 6).

### `_newton(X, y, lam)`: the learning algorithm
This is the actual "training". Plainly: it finds a **weight** for each of the 43 features. A positive weight means "this raises fraud risk", negative means "lowers it", and a larger number means a stronger effect. This is called **logistic regression**, one of the simplest and most explainable models, written by hand with numpy (the only maths library allowed).
- `lam` (set to 20) is a safety brake: it stops the model from going overboard on any one feature. This matters because about 1% to 2% of the training labels are wrong (the README says so).
- It is **deterministic**: same data in, same weights out, no randomness.

### `fit(train_df)`: Stage 1, learning
Step by step:
1. **Clean:** remove the 600 duplicate rows, sort by time.
2. **Replay:** go through the 120,000 payments one at a time in time order. For each one, compute its features from memory *before* adding it, then add it. This is crucial: it means every training feature was computed using only the past, exactly as it would be live.
3. **Don't trust fraud devices:** if a payment was labelled fraud, its device is *not* added to that customer's list of trusted devices.
4. **Choose the flag rule:** train on early data, test on the last two months of the training data, and try many cut-offs. Pick the one that scores best on F2 and cost-saving. Then train the final model on **all** the data.

The flag rule it learns has two parts: the probability must be at least `p_min`, **and** `probability × amount ≥ k × ₹150`. In plain words: *a big payment needs less suspicion to be flagged than a small one, because missing it costs more.*

### `score(txn)`: Stage 2, judging
1. Build the 43 features (`_features`).
2. Multiply by the learned weights, squash with `_sig`, and get a probability. `risk_score = 100 × probability`.
3. Apply the flag rule.
4. **Reasons (only if flagged):** for each feature, compute how much it pushed the score *up* compared with a typical payment. Take the top three **different** reason codes and report them.
5. Remember (privately) whether this payment was flagged, so `update` can use it.

`score` never changes memory.

### `update(txn)`: Stage 3, remembering
Calls `_apply` to add the payment to memory. **If the payment was flagged, its device is not added as trusted.** Otherwise a fraudster's first successful attack would make his own device look "known" for the next attack.

## 6. What we changed versus the weak baseline

The provided `fraud_detector.py` is deliberately weak. Full details with line numbers are in `PHANTOM_AUDIT.md`. Summary:

| Baseline problem | What we did |
|---|---|
| Only 4 hand-written rules with fixed numbers (amount > 50,000, hour < 5, failed ≥ 3, new device). | Learn weights for 43 features from the data. |
| Only 10 distinct scores, with 34,943 of 40,000 payments tied at 0. Ranking was almost meaningless. | A smooth score: 7,556 distinct values in our output. |
| `hour > 23` can never happen (hours go 0 to 23). | Removed; time-of-day is now a learned feature. |
| The fake `9,999,999` amount looked like a "huge amount" and was flagged: the baseline flagged 6 of the 22 test rows with it. | Treated as junk. We flag 0 of 22. |
| Flagged only 0.15% of payments, so it could catch at most about 12% of fraud. | Our flag rate is 1.39%, close to the real fraud rate. |
| The flag cut-off was a fixed 50. | Cut-off chosen from data, and aware of amounts. |
| Devices from fraud payments, and from the first fraudulent use, became "trusted". | Neither is trusted any more. |
| Customers with no history never triggered `NEW_DEVICE`. | An explicit "brand-new customer" feature. |
| Reasons were attached even to unflagged payments, and the top 3 were picked by order, not importance. | Reasons only on flagged rows, ranked by contribution. |
| Ignored category, channel, account age, IP, location and receiver completely. | All used. |

## 7. How we proved it doesn't cheat (no look-ahead)

The biggest risk in this kind of project is accidentally using the future. We tested it:
1. **Prefix test:** run the engine on 29,755 April payments, then on only the first 8,000. The scores of those first 8,000 were **identical**.
2. **Sabotage test:** we deliberately corrupted every payment after the first 8,000 (fake devices, ₹5 amounts). The scores of the first 8,000 did **not change**.
3. **Repeat test:** running the same payment twice through `score` gives the same answer, so `score` does not change memory.
4. **Determinism test:** two full runs on the real test file are **byte-identical**.

## 8. How we measured accuracy (the practice exam)

We have no labels for the real test file (May). So we built a **practice exam** from the labelled data, always respecting time:

- Train on January, test on February.
- Train on January and February, test on March.
- Train on January to March, test on April.

We did **not** shuffle the data randomly. A random split would let the model "see" the future and look better than it really is.

| Practice exam | PR-AUC | F2 | Cost-saving | **Final** | Flagged | Real fraud |
|---|---|---|---|---|---|---|
| Jan → Feb | 0.928 | 0.886 | 0.992 | **0.935** | 650 | 512 |
| Jan–Feb → Mar | 0.867 | 0.854 | 0.981 | **0.897** | 357 | 350 |
| Jan–Mar → Apr | 0.813 | 0.780 | 0.936 | **0.840** | 287 | 284 |

For comparison, the baseline scored about **0.16** on April. Even "flag everything" scored about 0.17.

**How to read this honestly:**
- Scores drop from February to April. We think this is **concept drift**, fraud patterns changing. Expect the real May score to look more like April than February.
- February contains many **device-sharing fraud rings**; April has almost none (0.00% of rows). So the early scores are flattered by those rings.
- We ran the model with six different "safety brake" settings (lam from 2 to 200). Results moved only slightly (average 0.88 to 0.89), so it is not fragile.

## 9. Technical checks passed

| Rule | Result |
|---|---|
| p95 latency under 50 ms | **0.09 ms** (about 500 times under the limit) |
| Every flagged payment has 1 to 3 reasons | **100%** (all 556 have exactly 3) |
| Unflagged payments have empty reasons | Yes, 0 violations |
| Only allowed libraries | numpy, pandas, standard library (scipy is installed but not needed) |
| Fixed seed and reproducible | Two runs byte-identical, also from a clean folder |
| Output format | 40,000 rows, exactly `txn_id,risk_score,prediction,reasons`, no missing scores |

## 10. Known weaknesses (say these yourself, don't wait to be asked)

1. **Stealthy fraud is missed.** In April we missed 62 of 284 frauds. Typical missed case: a small amount to a normal merchant, no failed attempts, established account. It looks exactly like a normal payment.
2. **We depend on patterns that may change.** If fraudsters stop reusing devices or switch from new accounts to hijacked old ones, some signals weaken. Round 2 is designed to test this.
3. **Some false alarms.** In April about 65 normal payments were flagged. In the real world these annoy customers.
4. **Our accuracy numbers are estimates.** They use our own version of the formulas, and the real May labels are hidden.
5. **Two odd weights.** Two small features (`u_fan3`, `bn_x_new_ben`) got large negative weights, probably noise. Their influence is small.
6. **Cut-off tuned on limited data.** The flag rule was tuned on two month-long windows, so some of it reflects that data.
7. **Simple model.** Logistic regression can't capture complicated feature interactions. We chose it for speed, explainability and the library limits.

## 11. What we would monitor in production

Fraud models decay. After deployment we would watch:
- **Flag rate per day.** A sudden jump or drop means something changed.
- **Score distribution.** If scores drift, so has the input data.
- **Reason-code mix.** If `SHARED_DEVICE` disappears and nothing replaces it, fraud tactics have changed.
- **Confirmed fraud vs. our flags,** as chargebacks and customer reports come in (labels arrive late, often weeks).
- **Missing-data rates** for IP, location and category, because broken data feeds look like fraud shifts.
- **Latency,** in case memory grows.
- **Customer complaints** about false alarms.

## 12. How we would retrain

- Retrain on a **rolling window** (for example the most recent 3 to 4 months) every month or when monitoring raises an alarm. This helps with drift.
- Always **validate on the future**, never a random split.
- Recheck the flag cut-off each time, because fraud prevalence changes (we saw 0.95% to 1.80% by month).
- Handle **label delay and noise:** recent weeks have incomplete labels, so exclude the newest days from training.
- Keep the previous model as a fallback and compare both for a while before switching.

## 13. Suggested 10-minute talk

| Minutes | What to say |
|---|---|
| 0 to 1 | The problem: fraud is 1 in 80, accuracy is useless, we must decide instantly, using only the past, with reasons. |
| 1 to 3 | The idea: fraud shows up in patterns. Our engine keeps memory of users, devices, IPs and receivers. Show the table in section 3. |
| 3 to 5 | The three stages: learn, judge, remember. Explain the replay trick (training mimics real life). |
| 5 to 6 | What we fixed in the baseline (pick 3 from section 6; the fake 9,999,999 and the 10 distinct scores make good stories). |
| 6 to 8 | Proof: no-look-ahead tests, practice-exam table, honest note about drift. Show the dashboard briefly. |
| 8 to 9 | Weaknesses and what we'd monitor. |
| 9 to 10 | Retraining plan and questions. |

## 14. Likely questions and honest answers

**"Why logistic regression and not a fancier model?"**
Only numpy, pandas and scipy are allowed in Round 1. It's also fast (0.09 ms), reproducible, and each feature's effect can be read directly, which gives real reason codes. A black-box model would struggle with the explainability rule.

**"Did you use the test labels or look at future data?"**
No. The test has no labels. The runner feeds one payment at a time, and our own tests prove earlier scores don't change when later rows change.

**"How do you know it isn't overfitting?"**
We tested only on later months than we trained on, in three separate folds, and the results stay strong and stable across different strength settings. Still, the real May score may be lower due to drift, and we say so.

**"Why was accuracy lower in April?"**
April has far fewer device-sharing fraud rings, which are easy to catch. What remains is stealthier fraud.

**"What does a reason code mean? Is it just a label?"**
Each code comes from the features that pushed that specific payment's score up the most. `SHARED_DEVICE` really means that device was used by another customer.

**"What happens when fraudsters adapt?"**
Some signals will weaken, which is why we'd monitor the reason-code mix and retrain regularly. A learned model with many signals degrades more gracefully than a few fixed rules, but we haven't tested Round 2 behaviour, so we won't claim robustness we haven't proven.

**"Why flag more when the amount is large?"**
Because the cost metric counts money. A missed ₹50,000 fraud hurts far more than a ₹150 false alarm, so the engine is willing to flag large payments at lower suspicion.

**"What would you do with more time?"**
Look at the stealthy frauds we miss, test robustness by simulating tactic changes, and try interaction features.

## 15. Glossary (for non-ML listeners)

- **Feature:** one piece of information about a payment (e.g. "account age is 5 days").
- **Model:** the set of learned weights that combines features into a risk score.
- **Training / fit:** the model studies past, labelled examples.
- **Label:** the known answer for a past payment: 1 means fraud, 0 means normal.
- **Streaming:** processing one item at a time, in order, as in real life.
- **Look-ahead / leakage:** accidentally using future information. It makes results look better than they really are.
- **Concept drift:** the patterns of fraud change over time, so an old model gets worse.
- **Threshold / cut-off:** the line above which we call a payment fraud.
- **False alarm (false positive):** a normal payment wrongly flagged. Here it costs ₹150.
- **Missed fraud (false negative):** a real fraud we didn't flag.
- **Precision:** of what we flagged, the share that was truly fraud.
- **Recall:** of all real fraud, the share we caught.
- **Latency:** how long one decision takes.
- **p95:** the speed that 95% of decisions beat.
- **Regularization (`lam`):** a brake that stops a model from over-trusting any single signal.
- **Reproducible:** run it again and get exactly the same result.
- **Mule account:** an account that receives stolen money.

## 16. Quick reference

```
Make the submission:   python run.py --engine team_phantom --test test_r1.csv --out submission.csv
Check accuracy:        python validate_rolling.py team_phantom
Dashboard (optional):  streamlit run app.py
```

If you rename the engine file to `team_<yourname>.py`, use that name (without `.py`) after `--engine`.

Deliverables: `submission.csv`, your renamed engine file, the 5-line note (approach, key features, what failed, bonus bugs), and optionally `PHANTOM_AUDIT.md` and this guide.

## 17. Five-line summary for the submission note

1. **Approach:** a streaming engine that keeps memory of users, devices, IPs and receivers, and scores each payment with a learned (logistic regression) model plus an amount-aware flag rule tuned on out-of-time data.
2. **Key features:** shared device or IP, burst of recent payments, new or young account, failed attempts, receiver used by many customers, risky category and channel, night hours, impossible travel.
3. **What failed or was weak:** stealthy small-amount fraud to normal merchants is missed (62 of 284 in April), and the accuracy drifts down from about 0.93 to 0.84 over the months.
4. **Bonus bugs in the baseline:** `hour > 23` is dead code; the `9,999,999` placeholder triggers a false HIGH_AMOUNT flag; only 10 distinct scores ruin ranking; fraud devices become trusted; reasons are kept on unflagged rows.
5. **Validated by:** chronological practice exams (0.935, 0.897, 0.840 versus baseline 0.16), no-look-ahead tests, byte-identical reruns, and p95 latency of 0.09 ms.
