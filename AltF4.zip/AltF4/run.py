"""
Streaming harness. DO NOT EDIT (judges run their own copy).

  python run.py --engine submission_template --test test_r1.csv --out submission.csv

Rules enforced here:
  * transactions are fed ONE AT A TIME in timestamp order  -> no look-ahead, no future data
  * test labels are never revealed (update() gets no label)
  * latency per score() call is measured; p95 must be < 50 ms
"""
import argparse
import importlib
import time

import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", default="fraud_detector")
    ap.add_argument("--train", default="train.csv")
    ap.add_argument("--test", default="test_r1.csv")
    ap.add_argument("--out", default="submission.csv")
    a = ap.parse_args()

    eng = importlib.import_module(a.engine).FraudEngine()
    train = pd.read_csv(a.train)
    test = pd.read_csv(a.test).sort_values(["timestamp", "txn_id"], kind="stable")

    t0 = time.perf_counter()
    eng.fit(train)
    print(f"fit() took {time.perf_counter() - t0:.1f}s")

    rows, lat = [], []
    for txn in test.to_dict("records"):
        s = time.perf_counter()
        r = eng.score(dict(txn))
        lat.append((time.perf_counter() - s) * 1000)
        eng.update(dict(txn))
        rows.append((txn["txn_id"], float(r["risk_score"]), int(r["prediction"]),
                     "|".join(r.get("reasons", [])[:3])))

    pd.DataFrame(rows, columns=["txn_id", "risk_score", "prediction", "reasons"]).to_csv(a.out, index=False)
    p95, mx = np.percentile(lat, 95), max(lat)
    print(f"wrote {a.out}  rows={len(rows)}  flagged={sum(r[2] for r in rows)}")
    print(f"latency  mean={np.mean(lat):.2f} ms  p95={p95:.2f} ms  max={mx:.1f} ms")
    if p95 > 50:
        print("!! p95 latency above 50 ms -> submission would be DISQUALIFIED in Round 3")


if __name__ == "__main__":
    main()
