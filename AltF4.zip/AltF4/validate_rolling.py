import sys, time, importlib
sys.path.insert(0,".")
import numpy as np, pandas as pd
from metrics import composite
eng_name = sys.argv[1] if len(sys.argv)>1 else "team_phantom"
df=pd.read_csv("train.csv").drop_duplicates("txn_id").sort_values(["timestamp","txn_id"],kind="stable")
folds=[("Jan->Feb","2026-01-01","2026-02-01","2026-03-01"),("Jan-Feb->Mar","2026-01-01","2026-03-01","2026-04-01"),("Jan-Mar->Apr","2026-01-01","2026-04-01","2026-05-01")]
mod=importlib.import_module(eng_name)
for name,a,b,c in folds:
    fit=df[(df.timestamp>=a)&(df.timestamp<b)]; val=df[(df.timestamp>=b)&(df.timestamp<c)]
    e=mod.FraudEngine(); t0=time.perf_counter(); e.fit(fit.copy()); ft=time.perf_counter()-t0
    S=[];P=[];R=[];lat=[]
    for t in val.drop(columns="label").to_dict("records"):
        s=time.perf_counter(); r=e.score(dict(t)); lat.append((time.perf_counter()-s)*1e3); e.update(dict(t))
        S.append(r["risk_score"]);P.append(r["prediction"]);R.append(r["reasons"])
    S=np.array(S);P=np.array(P); m=composite(val.label.values,S,P,val.amount.values)
    flagged=P==1; norc=sum(1 for p,r in zip(P,R) if p==1 and not r)
    print(f"{name:13s} fit={ft:4.1f}s p95={np.percentile(lat,95):.3f}ms flagged={P.sum():4d} ({P.mean():.4f}) fraud={int(val.label.sum())} "
          f"PR-AUC={m['pr_auc']:.3f} F2={m['f2']:.3f} cost={m['cost']:.3f} COMP={m['composite']:.3f} noReason={norc} cv=(obj={getattr(e,'cv_obj',0):.3f},pmin={getattr(e,'p_min',0)},k={getattr(e,'k',0)})")
