"""
Baseline fraud engine (deliberately weak). Same interface you must implement.
Run:  python run.py --engine fraud_detector --test test_r1.csv --out baseline_outputs.csv
"""


class FraudEngine:
    def fit(self, train_df):
        """Called once with the labelled history (pandas DataFrame)."""
        self.seen_devices = {}
        for u, d in zip(train_df["user_id"], train_df["device_id"]):
            self.seen_devices.setdefault(u, set()).add(d)

    def score(self, txn: dict) -> dict:
        """Called once per test transaction, in timestamp order. Past data only."""
        risk = 0
        reasons = []
        hour = int(txn["timestamp"][11:13])

        if txn["amount"] > 50000:
            risk += 35
            reasons.append("HIGH_AMOUNT")
        if hour < 5 or hour > 23:
            risk += 20
            reasons.append("ODD_HOUR")
        if txn["failed_attempts"] >= 3:
            risk += 30
            reasons.append("FAILED_ATTEMPTS")
        known = self.seen_devices.get(txn["user_id"], set())
        if known and txn["device_id"] not in known:
            risk += 20
            reasons.append("NEW_DEVICE")

        risk = min(risk, 100)
        return {"risk_score": risk, "prediction": int(risk >= 50), "reasons": reasons[:3]}

    def update(self, txn: dict):
        """Called right AFTER score(). Add this txn to your running state."""
        self.seen_devices.setdefault(txn["user_id"], set()).add(txn["device_id"])
